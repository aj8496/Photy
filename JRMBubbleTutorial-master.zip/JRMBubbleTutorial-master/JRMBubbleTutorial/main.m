//
//  main.m
//  JRMBubbleTutorial
//
//  Created by Caroline on 3/8/16.
//  Copyright © 2016 Caroline Harrison. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
